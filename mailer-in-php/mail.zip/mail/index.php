<?php
require_once("PHPMailer/PHPMailerAutoload.php");
require_once("sendMail/sendMail.php");

try{
    $mail = new SendMail();

    $Email = $_GET['email'];
    $body = $_GET['body'];
    $subject = $_GET['subject'];

    if(!empty($Email) && !empty($body) && !empty($subject)){
        $mail->Send($Email,$body,$subject);

        echo true;

    }
    else {
        echo false;
    }

  
    
 } catch (Exception $e) {
             echo "Message could not be sent. Mailer Error: {$this->mail->ErrorInfo}";
         }
?>