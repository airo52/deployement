var button = document.getElementById('submit');

button.addEventListener('click',()=>{
    var email = document.querySelector('#email').value;
    var password = document.querySelector('#password').value;


   var response =  validateEmail(email);

   if(response == true){
       if(password){
           sendAjaxRequest(email,password);
       }else{
           Errors("Password can not be empty");
       }
   }
   else
     Errors(response);

})

function validateEmail(email){

    if(email !==""){
    if (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(email))
    {
      return (true)
    }
      return "Wrong Email format";
}else{
    return "email can not be empty";
}
}

function validatePassword(password){
      if(password === ""){
          return false;
      }else{
          true;
      }
}
function Errors(params) {
    var df = document.getElementById('Error');
        df.innerHTML=params;
        setTimeout(() => {
            df.innerHTML="";
        }, 2000);
}

function sendAjaxRequest(email,password){
    
    var data = "email="+email+"&password="+password+"&control=Login";
       $.ajax({
           type:"POST",
           url:'home.php',
           cache:false,
           data:data,
           success:(resp)=>{
                var response = JSON.parse(resp);
                if(response === "Not Found"){
                  
                    Errors("Account Not Found");
              }

               else if(response == true){
                
                    window.location.href="home";
                }
                else 
                Errors(response);


           }
       })
}