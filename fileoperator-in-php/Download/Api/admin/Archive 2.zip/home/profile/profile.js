var button = document.getElementById('update');
button.addEventListener('click',()=>{
    var username = document.getElementById('username').value;
    var email = document.getElementById('email').value;
    var oldPassword = document.getElementById('oldPassword').value;
    var newPassword = document.getElementById('newPassword').value;
    var profile = document.getElementById('File').value;

    if(username !=="" || email !=="" || oldPassword !=="" || newPassword !=="" || profile !==""){
       // var data = "&control=updateProfile"+"&username="+username+"&email="+email+"&oldPassword="+oldPassword+"&password="+newPassword+"&profile="+document.getElementById('File').files[0];

        var image = document.getElementById('File').files[0];
        var formData = new FormData();
        formData.append("username",username);
        formData.append("email",email);
        formData.append("oldPassword",oldPassword);
        formData.append("password",newPassword);
        formData.append('profile',image);
        formData.append("control","updateProfile");
         $.ajax({
        type:'POST',
        url:'../home.php',
        cache:false,
        data:formData,
        processData: false,
        contentType: false,
        success:(data)=>{
            var response = JSON.parse(data);
            console.log(response);
          
        }
    })   
    }
    else{
        alert("All the fields can not be empty");
    }
})

