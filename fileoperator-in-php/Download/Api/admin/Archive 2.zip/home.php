<?php


require_once("php/config/db/db.php");
require_once("php/config/crypto/crypto.php");
require_once("php/config/db/queries.php");
require_once("PHPMailer/PHPMailerAutoload.php");
require_once("sendMail/sendMail.php");

$db = new DatabaseConfigaration();
$path = "php/functions/";


$control = $_POST['control'];


switch ($control) {
    case 'Login':
        
        require_once "php/login/auth.php";
        
        $auth = new auth($db);

        $result = $auth->InitAuth($_POST['email'],$_POST['password']);

        echo json_encode($result);

    
        break;

        case 'dashboard':
           include_once "$path"."details.php";

            $data = new Details($db);

            echo json_encode($data->Dashboard());
            
            break;

        case 'reservation':
            include_once "$path"."details.php";

            $data = new Details($db);

            echo json_encode($data->Reservation());
            break;   
            case "packages":
                include_once "$path"."details.php";

                $data = new Details($db);

               echo json_encode($data->getPacakage());
            break;
            
            case "adPackage":
              
                $valid_extensions = array('jpeg', 'jpg', 'png', 'bmp',); // valid extensions
                $pat = 'files/'; // upload directory
                
                if(isset($_FILES['image']))      $valid_extensions = array('jpeg', 'jpg', 'png', 'bmp',); // valid extensions
                $pat = 'files/'; // upload directory
                
                if(isset($_FILES['image']))
                {
                 $img = $_FILES['image']['name'];
                 $tmp = $_FILES['image']['tmp_name'];
                
                 // get uploaded file's extension
                 $ext = strtolower(pathinfo($img, PATHINFO_EXTENSION));
                
                 // can upload same image using rand function
                 $final_image = rand(1000,1000000).$img;
                
                 // check's valid format
                 if(in_array($ext, $valid_extensions)) 
                 {     
                  $pat = $pat.strtolower($final_image); 
                  function url(){
                   return  sprintf(
                      "%s://%s%s",
                      isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] != 'off' ? 'https' : 'http',$_SERVER['SERVER_NAME'], $_SERVER['REQUEST_URI']
                      
                    );

                  
                  }
                  
               
                
                  if(move_uploaded_file($tmp,$pat)) 
                  {
                  $ImagePath =str_replace("home.php", "",url()).$pat;

                   $title = $_POST['title'];
                   $capacity = $_POST['capacity'];
                   $description = $_POST['description'];
                   $price = $_POST['price'];
                   try {
                       //code...
                       include_once "$path"."create.php";

                   
                      $data = new create($db);

                      echo json_encode($data->AddPackage($ImagePath,$title,$capacity,$description,$price));
                   } catch (\Throwable $th) {
                       echo json_encode($th);
                   }


                  }

                 } 
                 else 
                 {
                  echo 'invalid file';
                 }
                }
              
            break;

            case "Edit":
              
                    $id= $_POST['id'];
                    $Id = $_POST['Id'];
                    include_once "$path"."create.php";
                    $data = new create($db);
    

                 echo json_encode($data->getEdit($id,$Id));
        
             break;

             case "update":

                $title = $_POST['title'];
                $capacity = $_POST['capacity'];
                $description = $_POST['description'];
                $price = $_POST['price'];
                $Cntrl = $_POST['c'];
                $descriptionId = $_POST['id'];
                $category = $_POST['category'];
               // echo json_encode($Cntrl);
               if($Cntrl === "ok"){
                    $ImagePath = $_POST['image'];
                    try {
                        //code...
                        include_once "$path"."create.php";
 
                    
                       $data = new create($db);
 
                       echo json_encode($data->UpdatePackage($ImagePath,$title,$capacity,$description,$price,$descriptionId,$category));
                    } catch (\Throwable $th) {
                        echo json_encode($th);
                    }
                }else{
                        
                   

                    $valid_extensions = array('jpeg', 'jpg', 'png', 'bmp',); // valid extensions
                    $pat = 'files/'; // upload directory
                    
                    if(isset($_FILES['image']))
                    {
                     $img = $_FILES['image']['name'];
                     $tmp = $_FILES['image']['tmp_name'];
                    
                     // get uploaded file's extension
                     $ext = strtolower(pathinfo($img, PATHINFO_EXTENSION));
                    
                     // can upload same image using rand function
                     $final_image = rand(1000,1000000).$img;
                    
                     // check's valid format
                     if(in_array($ext,$valid_extensions)) 
                     {     
                      $pat = $pat.strtolower($final_image); 
                      function url(){
                       return  sprintf(
                          "%s://%s%s",
                          isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] != 'off' ? 'https' : 'http',$_SERVER['SERVER_NAME'], $_SERVER['REQUEST_URI']
                          
                        );
    
                      
                      }
                      
                      if(move_uploaded_file($tmp,$pat)) 
                      {
                      $ImagePath =str_replace("home.php", "",url()).$pat;
                      try{
                      include_once "$path"."create.php";
 
                    
                      $data = new create($db);
                      echo json_encode($data->UpdatePackage($ImagePath,$title,$capacity,$description,$price,$descriptionId,$category));
                  
                   
                    } catch (\Throwable $th) {
                        echo json_encode($th);
                    }
    
                      }
    
                     } 
                     else 
                     {
                      echo 'invalid file';
                     }
                    }else{
                        echo json_encode("ok");
                    }

                }
                break;

                case "DeletePackage":

                    try {
                        
                        $id= $_POST['id'];
                        $Id = $_POST['Id'];
                        include_once "$path"."create.php";
 
                    
                       $data = new create($db);

                       echo json_encode($data->Delete($id,$Id));
                    
                        
                    } catch (\Throwable $th) {
                        //throw $th;
                         
                        echo json_encode($th);
                    }


                    break;
    
                    case "More":
                        $id= $_POST['id'];
                        $Id = $_POST['Id'];
                        $descId = $_POST['descId'];
                        include_once "$path"."create.php";
                        $data = new create($db);

                        echo json_encode($data->MoreDetails($id,$Id,$descId));

                        break;

                        case "confirm":
                            $id= $_POST['id'];
                            $amount = $_POST['amount'];
                            $method = $_POST['method'];
                            $transactionId = $_POST['transactionId'];
                            $email = $_POST['email'];
                            $package = $_POST['package'];

                            if(!empty($transactionId) && !empty($method) && !empty($amount) && !empty($id) && !empty($email)){
                            include_once "$path"."create.php";
                            $data = new create($db);
    
                            echo json_encode($data->Confirm($id,$amount,$method,$transactionId));

                            $sendMail = new sendMail();
                            $date = date("Y-m-d H:i:s");

                            $message = "<body><h3>Dear $email</h3>Ongollah Safaris Would like to confirm that your reservation has been made ON $date<br><span style='float:right'><p>Amount Paid:Ksh $amount</p><br><p>Package:$package</p></span></body>";

                            $sendMail->Send($email,$message,"Reservation payment Confirmation");


                            }else{
                                echo json_encode("provide all the Transaction Credentials");
                            }
                            break;


         case "updateProfile":
            $array = array();
            $check = false;
            $password = "";

            if(isset($_FILES['profile']))
            {
              
         $ImagePath= uploadImage($_FILES['profile']);
          
          
              }

            foreach ($_POST as $key => $value) {
                # code...
                if($key !== "control"){

                    if($key === "oldPassword" && !empty($value)){
                        $check = true;
                        $password = $value;
                        $array[$key] = $value;
                       

                    }
                    else{

                      
                            $array[$key] = $value;
                        
                      
                    }
                    
                }
            }

            //echo json_encode($ImagePath);
           // return;

           if($ImagePath == null || !$ImagePath)
            {
                unset($array['profile']);
            }else{
                $array['profile'] = $ImagePath;
            }

            if($check){
                require_once "php/login/auth.php";
        
                $auth = new auth($db);

                if($auth->confirmPassword($password)){

                    if(empty($array['password'])){
                             unset($array['password']);
                             echo json_encode('failed to update');
                             return;

                    }else{
                        
                        unset($array['oldPassword']);

                        if(empty($array['email'])){
                            unset($array['email']);
                        }
                        if(empty($array['username'])){
                            unset($array['username']); 
                        }

                        //update
                        session_start();
                        $id=$_SESSION['loged_user'];
                        include_once "$path"."create.php";
                        $data = new create($db);
        
                        echo json_encode($data->updateProfile($array,$id));
                        //echo json_encode("wrong password");
                    }

                }else{
                    echo json_encode("wrong password");
                }
            }else{
                unset($array['password']);
                unset($array['oldPassword']);
                if(empty($array['email'])){
                    unset($array['email']);
                }
                if(empty($array['username'])){
                    unset($array['username']); 
                }

                //update
                session_start();
             $id=$_SESSION['loged_user'];
             include_once "$path"."create.php";
                $data = new create($db);

                echo json_encode($data->updateProfile($array,$id));
            }
            break;    
            
            case "addAbout":
                try {
                    //code...
                    include_once "$path"."create.php";

                
                   $data = new create($db);

                   $description = $_POST['description'];

                   echo json_encode($data->addAbout($description));
                } catch (\Throwable $th) {
                    echo json_encode($th);
                }

                break;
                case "getAbout":
                    try {
                        
                        include_once "$path"."create.php";
    
                    
                       $data = new create($db);
    
                     
    
                       echo json_encode($data->getAbout());
                    } catch (\Throwable $th) {
                        echo json_encode($th);
                    }

                    break;

                    case "editAbout":
                        try {
                        
                            include_once "$path"."create.php";
        
                        
                           $data = new create($db);
        
                           $id = $_POST['id'];
        
                           echo json_encode($data->editAbout($id));
                        } catch (\Throwable $th) {
                            echo json_encode($th);
                        }
                        break;

                        case "deleteAbout":
                            try {
                        
                                include_once "$path"."create.php";
            
                            
                               $data = new create($db);
            
                               $id = $_POST['id'];
            
                               echo json_encode($data->deleteAbout($id));
                            } catch (\Throwable $th) {
                                echo json_encode($th);
                            }

                            break;
                            case "loadGallery":
                                try {
                        
                                    include_once "$path"."create.php";
                
                                
                                   $data = new create($db);
                
                                   echo json_encode($data->loadGallery(""));
                                } catch (\Throwable $th) {
                                    echo json_encode($th);
                                }
                                break;
                                case "addGallery":
                                    try {
                        
                                        include_once "$path"."create.php";
                                        $description=$_POST['description'];
                                        $title = $_POST['title'];

                                        if(!empty($description)){

                                        

                                        if(isset($_FILES['image']))
                                        {

                                          
                                     $ImagePath= uploadImage($_FILES['image']);
                                      
                                      
                                          }
                                        }else{
                                            echo json_encode('You have to provide description daily');
                                            return;
                                        }

                                          if(!empty($ImagePath)){
                                            $data = new create($db);

                                            
                    
                                            echo json_encode($data->addGallery($ImagePath,$description,$title));
                                          }
                                          else{
                                              echo json_encode('You have to provide Image');

                                              return;
                                          }
                    
                                    
                                       
                                    } catch (\Throwable $th) {
                                        echo json_encode($th);
                                    }
                                    break;

                                    case "GalleryEdit":
                                        try {
                        
                                            include_once "$path"."create.php";
                                            $description=$_POST['description'];
                                            $title = $_POST['title'];
    
                                            if(!empty($description)){
    
                                            
    
                                            if(isset($_FILES['image']))
                                            {
    
                                              
                                         $ImagePath= uploadImage($_FILES['image']);
                                          
                                          
                                              }
                                            }else{
                                                echo json_encode('You have to provide description');
                                                return;
                                            }
    
                                              if(!empty($ImagePath)){
                                                $data = new create($db);
    
                                                
                        
                                                echo json_encode($data->GalleryEdit($ImagePath,$description,mysqli_real_escape_string($db->con,$_POST['id']),$title));
                                              }
                                              else{
                                                  echo json_encode('You have to provide Image');
    
                                                  return;
                                              }
                        
                                        
                                           
                                        } catch (\Throwable $th) {
                                            echo json_encode($th);
                                        }
                                        break;

                                    case "deleteGallery";
                                       $id = $_POST['id'];
                                       $pat = $_POST['path'];

                                       include_once "$path"."create.php";
            
                            
                                      $data = new create($db);

                                      if($data->deleteGallery(mysqli_real_escape_string($db->con,$id))){
                                        echo json_encode(delete($pat));

                                      }else{
                                          echo json_encode(false);
                                      }


                                     break;

                                     case "EditGallery":
                                        $id = $_POST['id'];
                                     
 
                                        include_once "$path"."create.php";
             
                             
                                       $data = new create($db);
                                      
                                       echo json_encode($data->loadGallery(mysqli_real_escape_string($db->con,$id)));

                                        break;

                                        case 'getMessages':
                                            include_once "$path"."create.php";
             
                             
                                            $data = new create($db);
                                           
                                            echo json_encode($data->getMessages());
                                            break;

                                            case "getMessagesCount":
                                                include_once "$path"."create.php";
             
                             
                                                $data = new create($db);
                                               
                                                echo json_encode(count($data->getMessages()));

                                                break;

                                        case "Reply":
                                            $sendMail = new sendMail();
                                            $email = $_POST['email'];
                                            $id = $_POST['id'];
                                            $message = $_POST['message'];

                                            if(!empty($message)){

                                            include_once "$path"."create.php";
             
                             
                                            $data = new create($db);
                                           

                                       

                                           
                                            echo json_encode($data->Reply(mysqli_real_escape_string($db->con,$id),$message,$email,$sendMail));
                                            }else{
                                                echo json_encode("can not sen empty message");
                                            }

                                            break;   
                                            
                                            case "confirmContact":
                                                
                                                $id = $_POST['id'];
                                             
    
                                                include_once "$path"."create.php";
                 
                                 
                                                $data = new create($db);
                                               
                                                echo json_encode($data->confirmContact(mysqli_real_escape_string($db->con,$id)));
                                               

                                                break;
                                           case "loadBranches":
                                            include_once "$path"."create.php";
                 
                                 
                                            $data = new create($db);
                                           
                                            echo json_encode($data->loadBranches());
                                           
                                            break;  
                                            
                                            case "DeleteBranch":
                                                $id = $_POST['id'];
                                                include_once "$path"."create.php";
                 
                                 
                                                $data = new create($db);
                                               
                                                echo json_encode($data->DeleteBranch(mysqli_real_escape_string($db->con,$id)));
                                                break;
                                     case "addBranch":
                                          $name = $_POST['name'];
                                          include_once "$path"."create.php";
                 
                                 
                                                $data = new create($db);
                                               
                                                echo json_encode($data->addBranch(mysqli_real_escape_string($db->con,$name)));
                                        break;
                                    case "Logout":
                                        session_start();
                                        session_destroy();
                                        echo json_encode(true);
                                        break;
                default:


        # code...
    
        break;

}

function delete($image){
    $file_pointer = "files/".$image;
    if (!unlink($file_pointer)) { 
        return false;
    } 
    else { 
        return true;
    } 
}



function uploadImage($file){
    $valid_extensions = array('jpeg', 'jpg', 'png', 'bmp',); // valid extensions
    $pat = 'files/'; // upload directory
    
    //if(isset($_FILES['profile']))
    //{
     $img = $file['name'];//$_FILES['profile']['name'];
     $tmp = $file['tmp_name'];//$_FILES['profile']['tmp_name'];
    
     // get uploaded file's extension
     $ext = strtolower(pathinfo($img, PATHINFO_EXTENSION));
    
     // can upload same image using rand function
     $final_image = rand(1000,1000000).$img;
    
     // check's valid format
     if(in_array($ext,$valid_extensions)) 
     {     
      $pat = $pat.strtolower($final_image); 
      function url(){
       return  sprintf(
          "%s://%s%s",
          isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] != 'off' ? 'https' : 'http',$_SERVER['SERVER_NAME'], $_SERVER['REQUEST_URI']
          
        );

      
      }
      
      if(move_uploaded_file($tmp,$pat)) 
      {
      $ImagePath =str_replace("home.php", "",url()).$pat;
    
      return $ImagePath;

      }

     } 
     else 
     {
      return false;
     }
  //  }else{
     //   return false;
   // }  
}



?>