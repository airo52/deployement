<?php
require_once("PHPMailer/PHPMailerAutoload.php");
require_once("sendMail/sendMail.php");

try{
    $mail = new SendMail();
    
    $email='ireuben03@gmail.com';
    $body='<h2>body</h2>';
    $subject='mmos';
    
    $mail->Send($email,$body,$subject);
    
 } catch (Exception $e) {
             echo "Message could not be sent. Mailer Error: {$this->mail->ErrorInfo}";
         }
?>